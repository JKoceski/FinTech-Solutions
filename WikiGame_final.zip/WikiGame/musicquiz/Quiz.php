<?php 
    include_once '../Resource/Database.php';
    include_once '../Resource/session.php';
    
    $_SESSION['type'] = 'music';

    $sql = "SELECT question, option1, option2, option3, option4, answer 
            FROM ".$_SESSION['type'];
    $result = $db->query($sql);
    $result->setFetchMode(PDO::FETCH_ASSOC);
    $rows = array();

    while($row = $result->fetch())
    {
        $rows[] = $row;
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Quiz</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
    <link href="../quiz.css" rel="stylesheet">
</head>
<body>
Time : <span id="timer"></span>
<div id="quizContainer" class="container">
    <div class="title">Sports Quiz</div>
    <div id="question" class="question"></div>
    <label class="option"><input type="radio" name="option" value="1" /> <span id="opt1"></span></label>
    <label class="option"><input type="radio" name="option" value="2" /> <span id="opt2"></span></label>
    <label class="option"><input type="radio" name="option" value="3" /> <span id="opt3"></span></label>
    <label class="option"><input type="radio" name="option" value="4" /> <span id="opt4"></span></label>
    <button id="nextButton" class="next-btn" onclick="loadNextQuestion();">Next Question</button>
    <input type="button" value="Play Again" class="quit-btn" id="btnPlay" onClick="window.location.href = '../category.html';" />
    <input type="button" value="Home" class="quit-btn" id="btnHome" onClick="window.location.href = '../index.php';" />
</div>
<div id="result" class="container result" style="display:none;">
</div>

<script type="text/javascript">
    var questions = <?php echo json_encode($rows); ?>;
</script>
<script src="../Resource/jquery.min.js"></script>
<script src="../quiz-script.js"></script>
</body>
</html>