function startGame() {
    window.location.href='musicquiz/Quiz.html';
}