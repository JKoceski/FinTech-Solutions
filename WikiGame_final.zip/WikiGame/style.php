<?php
    header('Content-type: text/css; charset:UTF-8');
?>

h1 {
background-color: #0844a4;
color: yellow;
padding: 20px;
text-align: center;
margin-top: 5px;
margin-bottom: 0px;
font-size: 36px;
}

h3 {
font-size: 36px;
margin-left: 360px;
padding-top: 90px;


}

ul {
list-style-type: none;
margin: 0px;
padding: 5px;
overflow: hidden;
background-color: #0844a4;
margin-bottom: 0 !important;
border: 0 !important;

}

li {
float: right;
}

li a {
display: block;
color: white;
padding: 14px 16px;
text-decoration: none;
margin-top: 0px;
font-size: 20px;
margin-left: 5px;
margin-right: 5px;
}

/* Change the link color to #111 (black) on hover */
li a:hover {
background-color: #111;
}